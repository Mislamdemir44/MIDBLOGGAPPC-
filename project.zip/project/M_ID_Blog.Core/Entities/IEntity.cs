namespace M_ID_Blog.Core.Entities
{
    public interface IEntity
    {
    }
}