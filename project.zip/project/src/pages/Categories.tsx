export default function Categories() {
  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Categories</h1>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* Categories will be mapped here */}
      </div>
    </div>
  );
}